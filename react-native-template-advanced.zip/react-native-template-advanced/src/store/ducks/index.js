import { combineReducers } from 'redux';

const reducers = combineReducers({
  // Remova essa linha depois de adicionar seus ducks
  example: () => [],
});

export default reducers;
